import React from 'react';

export default function Container({ children, className = '' }) {
    return (
        <div className={`container mt-[90px] px-4 mx-auto ${className}`}>
            {children}
        </div>
    );
}
