import React from 'react'

export default function Favirate() {
  return (
    <div>
        <h1>Favirate</h1>
      
    </div>
  )
}
