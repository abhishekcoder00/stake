import React from 'react';
import PromoSlider from './../home page/PromoSlider';
import SearchInput from './SearchInput';
import Category from './Category';
import Container from './../home page/../../Container';
import Tabing from './Tabing';



export default function Home() {
  return (
    <div>
      <Container>
        <section>
          <PromoSlider />
        </section>
        <section className='input-search-box'>
          <SearchInput />
        </section>
        <section>
          <Category />
        </section>
          <Tabing/>
        <section>
       
        </section>
      </Container>
    </div>
  );
}
