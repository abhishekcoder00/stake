const Data = [
    {   
        span:"promo",
        name:"Daily Races",
        description: "Play in our $100,000 Daily Race",
        button:"Race Now",
        image: "image/1b892f712acd7b153d2b1f82298b71127800ce02-1026x1026-removebg-preview.png",

    },
    {   
        span:"promo",
        name:"Daily Races",
        description: "Play in our $100,000 Daily Race",
        button:"Race Now",
        image: "image/5dc0dd2eaf6d9ccaf58210a1ad9bb6e2de4405da-1026x1026-removebg-preview.png",

    },
    {   span:"promo",
        name:"Daily Races",
        description: "Play in our $100,000 Daily Race",
        button:"Race Now",
        image: "image/56cbc412ab91101a1ba9ed324b9afe57034ef8bb-1026x1026-removebg-preview.png",

    },
    {   
        span:"promo",
        name:"Daily Races",
        description: "Play in our $100,000 Daily Race",
        button:"Race Now",
        image: "image/74bfd7a4b7ec0c5c8902c91edfd86100ba85a1a9-1026x1026-removebg-preview.png",

    },
    {   
        span:"promo",
        name:"Daily Races",
        description: "Play in our $100,000 Daily Race",
        button:"Race Now",
        image: "image/987f30c51234e634fb61157044665f6e4e247d41-1026x1026-removebg-preview.png",

    },
    {   
        span:"promo",
        name:"Daily Races",
        description: "Play in our $100,000 Daily Race",
        button:"Race Now",
        image: "image/ca9fb909b678abef96deee8a1d4a3fd2a4f40afe-1026x1026-removebg-preview.png",

    }
]

export default Data;