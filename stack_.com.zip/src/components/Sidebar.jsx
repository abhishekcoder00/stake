import React from 'react';
import { Link } from 'react-router-dom';
import { FaRegStar } from 'react-icons/fa';
import { PiTargetBold } from 'react-icons/pi';
import { IoIosPaper, IoIosGift } from 'react-icons/io';
import { MdCasino } from 'react-icons/md';

function Sidebar() {
  return (
    <aside className="fixed top-0 left-0  z-40 h-screen  bg-[#1e2a34]  text-white">
      {/* <div className="p-6 overflow-x-hidden bg-red-800">
          <h1>fhw</h1>
          </div> */}
      <div className="h-full p-6 px-3 overflow-y-auto ">
        
        <ul className="space-y-2 font-medium ">
          <li>
            <Link to="/favirate" className="flex items-center p-2 rounded-lg hover:bg-[#213743]">
              <FaRegStar style={{ fontSize: '22px' }} />
              <span className="flex-1 ms-3">Favourites</span>
            </Link>
          </li>
          <li>
            <Link to="/recent" className="flex items-center p-2 rounded-lg hover:bg-[#213743]">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="24px" height="24px">
                <path d="M0 0h24v24H0z" fill="none" />
                <path d="M13 3a9 9 0 0 0-9 9H1l4 4 4-4H6a7 7 0 1 1 7 7 7 7 0 0 1-5-2.05L7.35 18.6A8.963 8.963 0 0 0 13 21c5 0 9-4 9-9s-4-9-9-9z" />
              </svg>
              <span className="flex-1 ms-3">Recent</span>
            </Link>
          </li>
          <li>
            <Link to="/challenges" className="flex items-center p-2 rounded-lg hover:bg-[#213743]">
              <PiTargetBold style={{ fontSize: '22px' }} />
              <span className="flex-1 ms-3">Challenges</span>
            </Link>
          </li>
          <li>
            <Link to="/games" className="flex items-center p-2 rounded-lg hover:bg-[#213743]">
              <IoIosPaper style={{ fontSize: '22px' }} />
              <span className="flex-1 ms-3">Games</span>
            </Link>
          </li>
          <li>
            <Link to="/casinos" className="flex items-center p-2 rounded-lg hover:bg-[#213743]">
              <MdCasino style={{ fontSize: '22px' }} />
              <span className="flex-1 ms-3">Casino</span>
            </Link>
          </li>
          <li>
            <Link to="/gift" className="flex items-center p-2 rounded-lg hover:bg-[#213743]">
              <IoIosGift style={{ fontSize: '22px' }} />
              <span className="flex-1 ms-3">Gifts</span>
            </Link>
          </li>
        </ul>
      </div>
    </aside>
  );
}

export default Sidebar;
